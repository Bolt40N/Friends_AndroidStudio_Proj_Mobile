package pt.iade.friends;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import pt.iade.friends.backgroundtasks.JSONArr;
import pt.iade.friends.backgroundtasks.JSONObjToArray;
import pt.iade.friends.databinding.ActivityInformationBinding;
import pt.iade.friends.databinding.ActivityMapsBinding;
import pt.iade.friends.models.SpotIMGModel;

public class InformationActivity extends AppCompatActivity {

    DrawerLayout drawer;
    TextView spotName;
    TextView servOpt;
    TextView spotAddress;
    TextView openHrs;
    TextView contactInfo;
    TextView evntDescription;
    TextView evntPrc;
    TextView evntRstrc;
    TextView evntDateTime;
    TextView evntTicket;
    ImageButton shareEvntbtn;
    ImageButton groupEvntbtn;
    ImageButton evntFavoritebtn;
    HorizontalScrollView spotImgs;

    JSONObject jsonArray2 = null;
    JSONObject jsonArray3 = null;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_information);

        drawer = findViewById(R.id.drawer_layout);
        spotName = findViewById(R.id.spotNameTV);
        servOpt = findViewById(R.id.serviceOptionsTV);
        spotAddress = findViewById(R.id.addressTV);
        openHrs = findViewById(R.id.openhoursTV);
        contactInfo = findViewById(R.id.contactinfoTV);
        evntDescription = findViewById(R.id.event_description);
        evntPrc = findViewById(R.id.event_price);
        evntRstrc = findViewById(R.id.event_restric);
        evntDateTime = findViewById(R.id.event_date_time);
        evntTicket = findViewById(R.id.event_buying_link);
        shareEvntbtn = findViewById(R.id.event_share_btn);
        groupEvntbtn = findViewById(R.id.create_group_btn);
        evntFavoritebtn = findViewById(R.id.event_fvrt_btn);
        spotImgs = findViewById(R.id.horizontal_spotview);

        JSONObjToArray task2 = new JSONObjToArray();
        JSONObjToArray task3 = new JSONObjToArray();

        Bundle extras = getIntent().getExtras();
        String sptname = extras.getString("SPTNM");

        shareEvntbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //share event on social media
                //empty for now
            }
        });
        groupEvntbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //create group for the event
                //empty for now
            }
        });

        try {

            jsonArray2 = task2.execute("https://friends-mobile-app.herokuapp.com/api/spots/searchinfos/" + sptname).get();
            spotName.setText(jsonArray2.getString("sptName"));
            //servOpt not defined
            spotAddress.setText(jsonArray2.getString("sptAddress"));
            //openHrs
            contactInfo.setText(jsonArray2.getString("sptContactInfo"));

        } catch (ExecutionException | InterruptedException | JSONException e) {
            e.printStackTrace();
            jsonArray2 = null;
        }

        try {
            jsonArray3 = task3.execute("https://friends-mobile-app.herokuapp.com/api/events/sptnames/"+sptname).get();
            evntDescription.setText(jsonArray3.getString("type"));
            evntPrc.setText(jsonArray3.getString("price")+"€");
            //restriction info fromm google;
            evntDateTime.setText("date: "+jsonArray3.getString("evDay")+"/"+jsonArray3.getString("evMonth")+"  time: "+
                    jsonArray3.getString("evHour")+":"+jsonArray3.getString("evMin"));

        }catch (ExecutionException | InterruptedException | JSONException e) {
            e.printStackTrace();
            jsonArray3 = null;
        }
    }
    //for side menu
    public void ClickMenu(View view) {
        openDrawer(drawer);
    }

    public static void openDrawer(DrawerLayout drawer) {
        drawer.openDrawer(GravityCompat.START);
    }

    public void ClickClose(View view) {
        closeDrawer(drawer);
    }

    public static void closeDrawer(DrawerLayout drawer) {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
    }

    public void ClickMap(View view) {
        MapsActivity.goToActivity(this, MapsActivity.class);
    }

    public void ClickProfile(View view) {
        MapsActivity.goToActivity(this, ProfileActivity.class);
    }

    public void ClickFriends(View view) {MapsActivity.goToActivity(this, DisplayFriendsActivity.class);}

    public void ClickGroups(View view) {
        MapsActivity.goToActivity(this, GroupsActivity.class);
    }

    public void ClickFavouriteSpots(View view) {MapsActivity.goToActivity(this, FavouritesActivity.class); }

    public void ClickSettings(View view) {MapsActivity.goToSettings(this);}

    public void ClickAboutUs(View view) {MapsActivity.goToActivity(this, AboutUsActivity.class);}

    public void ClickDisclaimers(View view) {
        //goToActivity(this,DisclaimersActivity.class);
        Toast.makeText(this, "Function 'Disclaimers' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickNotifications(View view) {
        //goToActivity(this,NotificationsActivity.class);
        Toast.makeText(this, "Function 'Notifications' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickPrivacy(View view) {
        //goToActivity(this,PrivacyActivity.class);
        Toast.makeText(this, "Function 'Privacy' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickHelp(View view) {MapsActivity.goToActivity(this, HelpActivity.class);}

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onPause() {
        super.onPause();
        closeDrawer(drawer);
    }

    public void milisecsToDate(){
        //change miliseconds format to date format for filtering events

    }
}
