package pt.iade.friends.Interests;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface InterestsService {
    @POST("create")
    Call<InterestsResponse> saveInterests(@Body InterestsRequest interestsResquest);
}
