package pt.iade.friends.Interests;

public class InterestsRequest {
    private String inttype;

    public String getInttype() {
        return inttype;
    }

    public void setInttype(String inttype) {
        this.inttype = inttype;
    }
}
