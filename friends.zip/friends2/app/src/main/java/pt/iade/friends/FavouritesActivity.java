package pt.iade.friends;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

public class FavouritesActivity extends AppCompatActivity {

    DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourites);

        drawer = findViewById(R.id.drawer_layout);
    }

    //for side menu
    public void ClickMenu(View view) {
        openDrawer(drawer);
    }

    public static void openDrawer(DrawerLayout drawer) {
        drawer.openDrawer(GravityCompat.START);
    }

    public void ClickClose(View view) {
        closeDrawer(drawer);
    }

    public static void closeDrawer(DrawerLayout drawer) {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
    }

    public void ClickMap(View view) {
        MapsActivity.goToActivity(this, MapsActivity.class);
    }

    public void ClickProfile(View view) {
        MapsActivity.goToActivity(this, ProfileActivity.class);
    }

    public void ClickFriends(View view) {MapsActivity.goToActivity(this, DisplayFriendsActivity.class);}

    public void ClickGroups(View view) {
        MapsActivity.goToActivity(this, GroupsActivity.class);
    }

    public void ClickFavouriteSpots(View view) {closeDrawer(drawer); }

    public void ClickSettings(View view) {MapsActivity.goToSettings(this);}

    public void ClickAboutUs(View view) {MapsActivity.goToActivity(this, AboutUsActivity.class);}

    public void ClickDisclaimers(View view) {
        //goToActivity(this,DisclaimersActivity.class);
        Toast.makeText(this, "Function 'Disclaimers' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickNotifications(View view) {
        //goToActivity(this,NotificationsActivity.class);
        Toast.makeText(this, "Function 'Notifications' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickPrivacy(View view) {
        //goToActivity(this,PrivacyActivity.class);
        Toast.makeText(this, "Function 'Privacy' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickHelp(View view) {MapsActivity.goToActivity(this, HelpActivity.class);}

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onPause() {
        super.onPause();
        closeDrawer(drawer);
    }
}
