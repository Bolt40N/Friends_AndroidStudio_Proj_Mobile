package pt.iade.friends;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

import pt.iade.friends.backgroundtasks.LoginBackgroundTask;

public class ProfileActivity extends AppCompatActivity {
    //button
    Button FButton;
    Button IButton;
    Button GButton;

    //drawable
    DrawerLayout drawer;

    //text view
    private TextView username, place, phoneNumber;

    //json
    JSONObject loginjson = null;
    JSONObject profilejson = null;


    //string
    static String userid;
    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        drawer = findViewById(R.id.drawer_layout);
        username = findViewById(R.id.username_tv_id);
        place = findViewById(R.id.place_tv_id);
        phoneNumber = findViewById(R.id.phone_number_tv_id);

        userid = getIntent().getStringExtra("key");
        LoginBackgroundTask task = new LoginBackgroundTask();
        try {
            loginjson = task.execute("https://friends-mobile-app.herokuapp.com/api/users/"+userid).get();
            username.setText(loginjson.getString("nm"));
            place.setText(loginjson.getString("email"));
            phoneNumber.setText(loginjson.getString("phoneNumber"));
        } catch (ExecutionException e) {
            e.printStackTrace();
            loginjson = null;
        } catch (InterruptedException e) {
            e.printStackTrace();
            loginjson = null;
        } catch (JSONException e) {
            e.printStackTrace();
        }

        FButton = findViewById(R.id.friends_button);
        FButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), DisplayFriendsActivity.class);
                startActivity(intent);
            }
        });

        IButton = findViewById(R.id.interests_button);
        IButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), InterestsActivity.class);
                try {
                    intent.putExtra("key", loginjson.getString("id"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                startActivity(intent);
            }
        });

        GButton = findViewById(R.id.groups_button);
        GButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), GroupsActivity.class);
                startActivity(intent);
            }
        });


    }
    //for side menu
    public void ClickMenu(View view) {
        openDrawer(drawer);
    }

    public static void openDrawer(DrawerLayout drawer) {
        drawer.openDrawer(GravityCompat.START);
    }

    public void ClickClose(View view) {
        closeDrawer(drawer);
    }

    public static void closeDrawer(DrawerLayout drawer) {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
    }

    public void ClickMap(View view) {
        MapsActivity.goToActivity(this, MapsActivity.class);
    }

    public void ClickProfile(View view) {
        closeDrawer(drawer);
    }

    public void ClickFriends(View view) {MapsActivity.goToActivity(this, DisplayFriendsActivity.class);}

    public void ClickGroups(View view) {
        MapsActivity.goToActivity(this, GroupsActivity.class);
    }

    public void ClickFavouriteSpots(View view) {MapsActivity.goToActivity(this, FavouritesActivity.class); }

    public void ClickSettings(View view) {MapsActivity.goToSettings(this);}

    public void ClickAboutUs(View view) {MapsActivity.goToActivity(this, AboutUsActivity.class);}

    public void ClickDisclaimers(View view) {
        //goToActivity(this,DisclaimersActivity.class);
        Toast.makeText(this, "Function 'Disclaimers' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickNotifications(View view) {
        //goToActivity(this,NotificationsActivity.class);
        Toast.makeText(this, "Function 'Notifications' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickPrivacy(View view) {
        //goToActivity(this,PrivacyActivity.class);
        Toast.makeText(this, "Function 'Privacy' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickHelp(View view) {MapsActivity.goToActivity(this, HelpActivity.class);}

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onPause() {
        super.onPause();
        closeDrawer(drawer);
    }

    //logout action
    public void ClickLogout(View view){
        logout(this);
    }
    private static void logout(Activity activity){
        //alert dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Logout");
        builder.setMessage("Do you want to logout of your account?");
        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                activity.finishAffinity();
                System.exit(0);
            }
        });
        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }

}