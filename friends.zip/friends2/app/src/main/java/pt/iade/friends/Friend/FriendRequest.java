package pt.iade.friends.Friend;

public class FriendRequest {

    private int mainuserfk;
    private String friendshipstatus;

    public int getMainuserfk() {
        return mainuserfk;
    }

    public void setMainuserfk(int mainuserfk) {
        this.mainuserfk = mainuserfk;
    }

    public String getFriendshipstatus() {
        return friendshipstatus;
    }

    public void setFriendshipstatus(String friendshipstatus) {
        this.friendshipstatus = friendshipstatus;
    }
}
