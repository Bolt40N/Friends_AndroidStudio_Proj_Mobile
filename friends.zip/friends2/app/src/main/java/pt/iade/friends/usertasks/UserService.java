package pt.iade.friends.usertasks;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface UserService
{
    @POST("create")
    Call<pt.iade.friends.usertasks.UserResponse> saveUsers(@Body UserRequest userRequest);
}
