package pt.iade.friends;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import pt.iade.friends.Interests.ApiClientI;
import pt.iade.friends.Interests.InterestsRequest;
import pt.iade.friends.Interests.InterestsResponse;
import pt.iade.friends.Interests.InterestsRequest;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddInterestsActivity extends AppCompatActivity {

    EditText InterestsN;
    Button addInterests;
    DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_interests);

        drawer = findViewById(R.id.drawer_layout);
        InterestsN = findViewById(R.id.Iname);
        addInterests = findViewById(R.id.addI);
        addInterests.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveInterests(createRequest());
                Intent goInterest = new Intent(getApplicationContext(), InterestsActivity.class);
                startActivity(goInterest);
            }
        });
    }

    public InterestsRequest createRequest() {
        InterestsRequest interestsRequest = new InterestsRequest();
        interestsRequest.setInttype(InterestsN.getText().toString());

        return interestsRequest;
    }

    public void saveInterests(InterestsRequest interestsResquest)
    {
        Call<InterestsResponse> interestsResponseCall = ApiClientI.getInterestsService().saveInterests(interestsResquest);
        interestsResponseCall.enqueue(new Callback<InterestsResponse>() {
            @Override
            public void onResponse(Call<InterestsResponse> call, Response<InterestsResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(AddInterestsActivity.this, "Saved Sucessfully", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(AddInterestsActivity.this, "Saved Sucessfully", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<InterestsResponse> call, Throwable t)
            {
                Toast.makeText(AddInterestsActivity.this,"Request Failed"+t.getLocalizedMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }
    //for side menu
    public void ClickMenu(View view) {
        openDrawer(drawer);
    }

    public static void openDrawer(DrawerLayout drawer) {
        drawer.openDrawer(GravityCompat.START);
    }

    public void ClickClose(View view) {
        closeDrawer(drawer);
    }

    public static void closeDrawer(DrawerLayout drawer) {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
    }

    public void ClickMap(View view) {
        MapsActivity.goToActivity(this, MapsActivity.class);
    }

    public void ClickProfile(View view) {
        MapsActivity.goToActivity(this, ProfileActivity.class);
    }

    public void ClickFriends(View view) {MapsActivity.goToActivity(this, DisplayFriendsActivity.class);}

    public void ClickGroups(View view) {
        MapsActivity.goToActivity(this, GroupsActivity.class);
    }

    public void ClickFavouriteSpots(View view) {MapsActivity.goToActivity(this,FavouritesActivity.class); }

    public void ClickSettings(View view) {MapsActivity.goToSettings(this);}

    public void ClickAboutUs(View view) {MapsActivity.goToActivity(this, AboutUsActivity.class);}

    public void ClickDisclaimers(View view) {
        //goToActivity(this,DisclaimersActivity.class);
        Toast.makeText(this, "Function 'Disclaimers' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickNotifications(View view) {
        //goToActivity(this,NotificationsActivity.class);
        Toast.makeText(this, "Function 'Notifications' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickPrivacy(View view) {
        //goToActivity(this,PrivacyActivity.class);
        Toast.makeText(this, "Function 'Privacy' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickHelp(View view) {MapsActivity.goToActivity(this, HelpActivity.class);}

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onPause() {
        super.onPause();
        closeDrawer(drawer);
    }
}