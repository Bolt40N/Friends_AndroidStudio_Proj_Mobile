package pt.iade.friends.usertasks;

public class UserRequest
{
    private String useremail;
    private String userphonenumber;
    private String usernm;
    private String userplace;
    private String userpassword;

    public String getUseremail() {
        return useremail;
    }

    public void setUseremail(String useremail) {
        this.useremail = useremail;
    }

    public String getUserphonenumber() {
        return userphonenumber;
    }

    public void setUserphonenumber(String userphonenumber) {
        this.userphonenumber = userphonenumber;
    }

    public String getUsernm() {
        return usernm;
    }

    public void setUsernm(String usernm) {
        this.usernm = usernm;
    }

    public String getUserplace() {
        return userplace;
    }

    public void setUserplace(String userplace) {
        this.userplace = userplace;
    }

    public String getUserpassword() {
        return userpassword;
    }

    public void setUserpassword(String userpassword) {
        this.userpassword = userpassword;
    }
}
