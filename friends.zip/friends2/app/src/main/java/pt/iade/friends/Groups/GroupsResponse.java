package pt.iade.friends.Groups;

public class GroupsResponse {

    private String groupname;
    private int groupid;
    private int ownerid;
    private int friendfk;

    public String getGroupname() {
        return groupname;
    }

    public void setGroupname(String groupname) {
        this.groupname = groupname;
    }

    public int getGroupid() {
        return groupid;
    }

    public void setGroupid(int groupid) {
        this.groupid = groupid;
    }

    public int getOwnerid() {
        return ownerid;
    }

    public void setOwnerid(int ownerid) {
        this.ownerid = ownerid;
    }

    public int getFriendfk() {
        return friendfk;
    }

    public void setFriendfk(int friendfk) {
        this.friendfk = friendfk;
    }
}
