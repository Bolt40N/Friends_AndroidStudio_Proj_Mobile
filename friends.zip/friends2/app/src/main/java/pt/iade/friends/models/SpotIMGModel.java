package pt.iade.friends.models;

public class SpotIMGModel {
    private static int spotIMGid;
    public SpotIMGModel(int spotIMGid){this.spotIMGid=spotIMGid;}
    public static int getSpotIMGid(){return spotIMGid;}
    public static void setSpotIMGid(int spotIMGid){SpotIMGModel.spotIMGid = spotIMGid;}
}
