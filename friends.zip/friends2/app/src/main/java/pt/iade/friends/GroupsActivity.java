package pt.iade.friends;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

import pt.iade.friends.backgroundtasks.LoginBackgroundTask;

public class GroupsActivity extends AppCompatActivity{

    DrawerLayout drawer;
    static String userid;
    JSONObject loginjson = null;
    private TextView show, show1, show2;
    Button add2;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_groups);
        drawer = findViewById(R.id.drawer_layout);
        show = findViewById(R.id.Gn);
        show1 = findViewById(R.id.Go);
        show2 = findViewById(R.id.Gf);

        userid = getIntent().getStringExtra("key");
        LoginBackgroundTask task = new LoginBackgroundTask();
        try {
            loginjson = task.execute("https://friends-mobile-app.herokuapp.com/api/friendgroup/"+userid).get();
            show.setText(loginjson.getString("groupName"));
            show1.setText(loginjson.getString("ownerId"));
            show2.setText(loginjson.getString("friendFk"));
        } catch (ExecutionException e) {
            e.printStackTrace();
            loginjson = null;
        } catch (InterruptedException e) {
            e.printStackTrace();
            loginjson = null;
        } catch (JSONException e) {
            e.printStackTrace();
        }

        add2 = findViewById(R.id.btnadd2);
        add2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent goadd = new Intent(getApplicationContext(),AddFriendsActivity.class);
                startActivity(goadd);
            }
        });
    }
    //for side menu
    public void ClickMenu(View view) {
        openDrawer(drawer);
    }

    public static void openDrawer(DrawerLayout drawer) {
        drawer.openDrawer(GravityCompat.START);
    }

    public void ClickClose(View view) {
        closeDrawer(drawer);
    }

    public static void closeDrawer(DrawerLayout drawer) {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
    }

    public void ClickMap(View view) {
        MapsActivity.goToActivity(this, MapsActivity.class);
    }

    public void ClickProfile(View view) {
        MapsActivity.goToActivity(this, ProfileActivity.class);
    }

    public void ClickFriends(View view) {MapsActivity.goToActivity(this, DisplayFriendsActivity.class);}

    public void ClickGroups(View view) {
        closeDrawer(drawer);
    }

    public void ClickFavouriteSpots(View view) {MapsActivity.goToActivity(this, FavouritesActivity.class); }

    public void ClickSettings(View view) {MapsActivity.goToSettings(this);}

    public void ClickAboutUs(View view) {MapsActivity.goToActivity(this, AboutUsActivity.class);}

    public void ClickDisclaimers(View view) {
        //goToActivity(this,DisclaimersActivity.class);
        Toast.makeText(this, "Function 'Disclaimers' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickNotifications(View view) {
        //goToActivity(this,NotificationsActivity.class);
        Toast.makeText(this, "Function 'Notifications' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickPrivacy(View view) {
        //goToActivity(this,PrivacyActivity.class);
        Toast.makeText(this, "Function 'Privacy' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickHelp(View view) {MapsActivity.goToActivity(this, HelpActivity.class);}

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onPause() {
        super.onPause();
        closeDrawer(drawer);
    }
}