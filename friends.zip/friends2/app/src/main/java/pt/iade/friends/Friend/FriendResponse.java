package pt.iade.friends.Friend;

public class FriendResponse {

    private int mainuserfk;
    private int friendid;
    private String friendshipstatus;

    public int getMainuserfk() {
        return mainuserfk;
    }

    public void setMainuserfk(int mainuserfk) {
        this.mainuserfk = mainuserfk;
    }

    public int getFriendid() {
        return friendid;
    }

    public void setFriendid(int friendid) {
        this.friendid = friendid;
    }

    public String getFriendshipstatus() {
        return friendshipstatus;
    }

    public void setFriendshipstatus(String friendshipstatus) {
        this.friendshipstatus = friendshipstatus;
    }
}
