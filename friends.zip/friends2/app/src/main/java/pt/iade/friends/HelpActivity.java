package pt.iade.friends;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

public class HelpActivity extends AppCompatActivity {

    DrawerLayout drawer;
    Button helpEmailBtn;
    EditText userEmail;
    EditText helpMessage;
    EditText helpEmailSubject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        drawer = findViewById(R.id.drawer_layout);
        userEmail = findViewById(R.id.user_email_edt);
        helpMessage = findViewById(R.id.help_message);
        helpEmailBtn = findViewById(R.id.help_email_btn);
        helpEmailSubject = findViewById(R.id.email_subject_edt);

    }

    public void sendHelp(View view) {
        Log.i("Send email", "");

        String[] TO = {"help@friends.com"};
        String[] CC = {userEmail.getText().toString()};
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/plain");

        emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
        emailIntent.putExtra(Intent.EXTRA_CC, CC);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, helpEmailSubject.getText().toString());
        emailIntent.putExtra(Intent.EXTRA_TEXT, helpMessage.getText().toString());

        try {
            startActivity(Intent.createChooser(emailIntent, "Send question to help"));
            finish();
            Log.i("ticket sent", "");
        } catch (android.content.ActivityNotFoundException ex) {
            noEmailClient();
        }
    }

    private void noEmailClient() {
        Toast.makeText(this, "No email app available", Toast.LENGTH_SHORT).show();
    }

    //for side menu
    public void ClickMenu(View view) {
        openDrawer(drawer);
    }

    public static void openDrawer(DrawerLayout drawer) {
        drawer.openDrawer(GravityCompat.START);
    }

    public void ClickClose(View view) {
        closeDrawer(drawer);
    }

    public static void closeDrawer(DrawerLayout drawer) {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
    }

    public void ClickMap(View view) {
        MapsActivity.goToActivity(this, MapsActivity.class);
    }

    public void ClickProfile(View view) {
        MapsActivity.goToActivity(this, ProfileActivity.class);
    }

    public void ClickFriends(View view) {MapsActivity.goToActivity(this, DisplayFriendsActivity.class);}

    public void ClickGroups(View view) {
        MapsActivity.goToActivity(this, GroupsActivity.class);
    }

    public void ClickFavouriteSpots(View view) {MapsActivity.goToActivity(this, FavouritesActivity.class);}

    public void ClickSettings(View view) {MapsActivity.goToSettings(this);}

    public void ClickAboutUs(View view) {MapsActivity.goToActivity(this, AboutUsActivity.class);}

    public void ClickDisclaimers(View view) {
        //goToActivity(this,DisclaimersActivity.class);
        Toast.makeText(this, "Function 'Disclaimers' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickNotifications(View view) {
        //goToActivity(this,NotificationsActivity.class);
        Toast.makeText(this, "Function 'Notifications' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickPrivacy(View view) {
        //goToActivity(this,PrivacyActivity.class);
        Toast.makeText(this, "Function 'Privacy' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickHelp(View view) {closeDrawer(drawer);}

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onPause() {
        super.onPause();
        closeDrawer(drawer);
    }
}
