package pt.iade.friends.Interests;

public class InterestsResponse {
    private String inttype;
    private int interestid;

    public String getInttype() {
        return inttype;
    }

    public void setInttype(String inttype) {
        this.inttype = inttype;
    }

    public int getInterestid() {
        return interestid;
    }

    public void setInterestid(int interestid) {
        this.interestid = interestid;
    }
}
