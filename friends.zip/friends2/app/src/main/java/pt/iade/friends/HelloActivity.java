package pt.iade.friends;


import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HelloActivity extends AppCompatActivity
{
    Button Signbtn;
    Button Notbtn;
    Button Registernbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hello_main);

        Registernbtn = findViewById(R.id.button2);
        Registernbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent goRegister = new Intent(getApplicationContext(),RegisterActivity.class);
                startActivity(goRegister);
            }
        });

        Signbtn = findViewById(R.id.button);
        Signbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent goLogin = new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(goLogin);
            }
        });

        Notbtn = findViewById(R.id.button1);
        Notbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v1){
                Intent goMap = new Intent(getApplicationContext(), MapsActivity.class);
                startActivity(goMap);
            }
        });

    }
}