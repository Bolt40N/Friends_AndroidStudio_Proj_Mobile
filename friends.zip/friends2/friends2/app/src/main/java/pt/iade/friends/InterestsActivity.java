package pt.iade.friends;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import android.view.View;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;

import pt.iade.friends.adapters.InterestsAdapter;
import pt.iade.friends.models.InterestsModel;

public class InterestsActivity extends AppCompatActivity{

    GridView interestGV;
    DrawerLayout drawer;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interests);

        drawer = findViewById(R.id.drawer_layout);

        interestGV = findViewById(R.id.idGVinterests);
        ArrayList<InterestsModel> interestsArrayList = new ArrayList<>();

        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));
        interestsArrayList.add(new InterestsModel(R.drawable.info_icon));

        InterestsAdapter adapter = new InterestsAdapter(this, interestsArrayList);
        interestGV.setAdapter(adapter);


    }
    //sidemenu
    public void ClickMenu(View view){MapsActivity.openDrawer(drawer);}
    public void ClickClose(View view){MapsActivity.closeDrawer(drawer);}
    public void ClickMap(View view){MapsActivity.goToActivity(this,MapsActivity.class);}
    public void ClickProfile(View view){MapsActivity.goToActivity(this,ProfileActivity.class);}
    public void ClickFriends(View view){MapsActivity.goToActivity(this, DisplayFriendsActivity.class);}
    public void ClickGroups(View view){
        MapsActivity.goToActivity(this,GroupsActivity.class);
    }
    public void ClickFavouriteSpots(View view){
        //goToActivity(this,FavouriteSpotsActivity.class);
        Toast.makeText(this, "Function 'Favourite Spots' is not available yet", Toast.LENGTH_LONG).show();
    }
    public void ClickSettings(View view){
        //goToActivity(this,SettingsActivity.class);
        Toast.makeText(this, "Function 'Settings' is not available yet", Toast.LENGTH_LONG).show();
    }
    public void ClickAboutUs(View view){
        //goToActivity(this,AboutUsActivity.class);
        Toast.makeText(this, "Function 'About us' is not available yet", Toast.LENGTH_LONG).show();
    }
    public void ClickDisclaimers(View view){
        //goToActivity(this,DisclaimersActivity.class);
        Toast.makeText(this, "Function 'Disclaimers' is not available yet", Toast.LENGTH_LONG).show();
    }
    public void ClickNotifications(View view){
        //goToActivity(this,NotificationsActivity.class);
        Toast.makeText(this, "Function 'Notifications' is not available yet", Toast.LENGTH_LONG).show();
    }
    public void ClickPrivacy(View view){
        //goToActivity(this,PrivacyActivity.class);
        Toast.makeText(this, "Function 'Privacy' is not available yet", Toast.LENGTH_LONG).show();
    }
    public void ClickHelp(View view){
        //goToActivity(this,HelpActivity.class);
        Toast.makeText(this, "Function 'Help' is not available yet", Toast.LENGTH_LONG).show();
    }
    public void ClickPermissions(View view){
        //goToActivity(this,PermissionsActivity.class);
        Toast.makeText(this, "Function 'Permissions' is not available yet", Toast.LENGTH_LONG).show();
    }
    @Override
    protected void onPause(){
        super.onPause();
        MapsActivity.closeDrawer(drawer);
    }
}