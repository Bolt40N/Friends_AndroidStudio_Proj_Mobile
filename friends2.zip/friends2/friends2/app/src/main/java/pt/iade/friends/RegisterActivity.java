package pt.iade.friends;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import pt.iade.friends.models.UserModel;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RegisterActivity extends AppCompatActivity {

    private Button travelButton;
    private TextView responseTV;
    private EditText username, password, email, phoneNumber, place;
    private ProgressBar loading;
    JSONObject registerjson = null;
    String[] mensagens = {"Fill In All Fields", "Record Done Successfully"};

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        email = findViewById(R.id.email);
        phoneNumber = findViewById(R.id.number);
        place = findViewById(R.id.place);
        responseTV = findViewById(R.id.idTVResponse);
        loading = findViewById(R.id.idLoading);

        travelButton = findViewById(R.id.travelButton);
        travelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);

                if (username.getText().toString().isEmpty() && password.getText().toString().isEmpty() && email.getText().toString().isEmpty()
                        && phoneNumber.getText().toString().isEmpty() && place.getText().toString().isEmpty()) {
                    Toast.makeText(RegisterActivity.this, "Please enter all values", Toast.LENGTH_SHORT).show();
                    return;
                }
                postData(username.getText().toString(), password.getText().toString(), email.getText().toString(), phoneNumber.getText().toString(), place.getText().toString());
            }
        });
    }

    private void postData(String username, String password, String email, String phoneNumber, String place)
    {
        loading.setVisibility(View.VISIBLE);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://friends-mobile-app.herokuapp.com/api/users/create/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        RetrofitAPI retrofitAPI = retrofit.create(RetrofitAPI.class);

        UserModel user = new UserModel(email,username,phoneNumber,place,password);

        Call<UserModel> call = retrofitAPI.createPost(user);

        call.enqueue(new Callback<UserModel>() {
            @Override
            public void onResponse(Call<UserModel> call, Response<UserModel> response) {
                Toast.makeText(RegisterActivity.this,"Register Done", Toast.LENGTH_SHORT).show();
                UserModel responseFromApi = response.body();
            }
            @Override
            public void onFailure(Call<UserModel> call, Throwable t) {
                Toast.makeText(RegisterActivity.this, "Register failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

}