package pt.iade.friends.models;

public class InterestsModel {
    private static int interestID;

    public InterestsModel(int interestID){ this.interestID = interestID;
    }

    public static int getInterestID() {
        return interestID;
    }

    public void setInterestID(int interestID) {this.interestID = interestID;
    }
}
