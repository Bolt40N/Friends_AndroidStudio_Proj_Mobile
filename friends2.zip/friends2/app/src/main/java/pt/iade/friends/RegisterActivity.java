package pt.iade.friends;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import pt.iade.friends.usertasks.APIClient;
import pt.iade.friends.usertasks.UserRequest;
import pt.iade.friends.usertasks.UserResponse;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
public class RegisterActivity extends AppCompatActivity {

    Button travelButton;
    EditText username, password, email, phoneNumber, place;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        username = findViewById(R.id.Rusername);
        password = findViewById(R.id.Rpassword);
        email = findViewById(R.id.Remail);
        phoneNumber = findViewById(R.id.RphoneNumber);
        place = findViewById(R.id.Rplace);

        travelButton = findViewById(R.id.Rbtn);
        travelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveUser(createRequest());
                Intent goLogin = new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(goLogin);
            }
        });
    }

    public UserRequest createRequest()
    {
        UserRequest userRequest = new UserRequest();
        userRequest.setNm(username.getText().toString());
        userRequest.setPassword(password.getText().toString());
        userRequest.setEmail(email.getText().toString());
        userRequest.setPhoneNumber(phoneNumber.getText().toString());
        userRequest.setPlace(place.getText().toString());

        return userRequest;
    }

    public void saveUser(UserRequest userRequest)
    {
        Call<UserResponse> userResponseCall = APIClient.getUserService().saveUsers(userRequest);
        userResponseCall.enqueue(new Callback<UserResponse>() {
            @Override
            public void onResponse(Call<UserResponse> call, Response<UserResponse> response) {
                if (response.isSuccessful())
                {
                    Toast.makeText(RegisterActivity.this,"Saved Sucessfullly",Toast.LENGTH_LONG).show();
                }else
                {
                    Toast.makeText(RegisterActivity.this,"Saved Sucessfullly",Toast.LENGTH_LONG).show();
                }
            }
            @Override
            public void onFailure(Call<UserResponse> call, Throwable t)
            {
                Toast.makeText(RegisterActivity.this,"Request Failed"+t.getLocalizedMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }
}