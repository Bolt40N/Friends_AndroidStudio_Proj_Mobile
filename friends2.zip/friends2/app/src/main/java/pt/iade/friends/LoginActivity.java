package pt.iade.friends;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

import pt.iade.friends.backgroundtasks.LoginBackgroundTask;

public class LoginActivity extends AppCompatActivity {

    EditText Luser, Lpass;
    Button Lbtn;
    JSONObject loginjson = null;
    String userID;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Luser = findViewById(R.id.Lusername);
        Lpass = findViewById(R.id.Lpassword);
        Lbtn = findViewById(R.id.Lbtn);
    }

    public  void onClick(View v){

        LoginBackgroundTask task = new LoginBackgroundTask();

        try {
            loginjson = task.execute("https://friends-mobile-app.herokuapp.com/api/users/" + Luser.getText().toString() + "/" + Lpass.getText().toString()).get();
            Intent myIntent = new Intent(this, ProfileActivity.class);
            myIntent.putExtra("key",loginjson.getString("id"));
            this.startActivity(myIntent);
        } catch (ExecutionException e){
            e.printStackTrace();
            loginjson = null;
        } catch (InterruptedException e){
            e.printStackTrace();
            loginjson = null;
        } catch (JSONException e){
            e.printStackTrace();
        }
    }
}
