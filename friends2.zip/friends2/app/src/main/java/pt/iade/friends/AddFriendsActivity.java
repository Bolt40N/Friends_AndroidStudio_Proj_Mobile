package pt.iade.friends;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import pt.iade.friends.models.FriendsModel;

public class AddFriendsActivity extends AppCompatActivity{
    private FriendsModel myFriend;
    EditText fName, fEmail;
    Button addFriend;
    DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_friends);

        this.myFriend = new FriendsModel("UserModel");

        fName = findViewById(R.id.fname);
        fEmail = findViewById(R.id.femail);
        addFriend = findViewById(R.id.add);

        drawer.findViewById(R.id.drawer_layout);
    }

    public void AddFriend(View view) {
        String name = " ";
        String email = " ";

        if (!fName.getText().toString().isEmpty()) {
            name = fName.getText().toString();
            Log.i("NAME: ", name);

            if (!fEmail.getText().toString().isEmpty()) {
                name = fEmail.getText().toString();
                Log.i("Friend Email: ", email);
            }
        }
    }

    public void checkFriend(View v) {
        Toast.makeText(this, "FriendsModel: " + this.myFriend.numeroFriend(), Toast.LENGTH_SHORT).show();
    }

    //sidemenu
    public void ClickMenu(View view){MapsActivity.openDrawer(drawer);}
    public void ClickClose(View view){MapsActivity.closeDrawer(drawer);}
    public void ClickMap(View view){MapsActivity.goToActivity(this,MapsActivity.class);}
    public void ClickProfile(View view){MapsActivity.goToActivity(this, ProfileActivity.class);}
    public void ClickFriends(View view){MapsActivity.goToActivity(this, DisplayFriendsActivity.class);}
    public void ClickGroups(View view){
        MapsActivity.goToActivity(this,GroupsActivity.class);
    }
    public void ClickFavouriteSpots(View view){
        //goToActivity(this,FavouriteSpotsActivity.class);
        Toast.makeText(this, "Function 'Favourite Spots' is not available yet", Toast.LENGTH_LONG).show();
    }
    public void ClickSettings(View view){
        //goToActivity(this,SettingsActivity.class);
        Toast.makeText(this, "Function 'Settings' is not available yet", Toast.LENGTH_LONG).show();
    }
    public void ClickAboutUs(View view){
        //goToActivity(this,AboutUsActivity.class);
        Toast.makeText(this, "Function 'About us' is not available yet", Toast.LENGTH_LONG).show();
    }
    public void ClickDisclaimers(View view){
        //goToActivity(this,DisclaimersActivity.class);
        Toast.makeText(this, "Function 'Disclaimers' is not available yet", Toast.LENGTH_LONG).show();
    }
    public void ClickNotifications(View view){
        //goToActivity(this,NotificationsActivity.class);
        Toast.makeText(this, "Function 'Notifications' is not available yet", Toast.LENGTH_SHORT).show();
    }
    public void ClickPrivacy(View view){
        //goToActivity(this,PrivacyActivity.class);
        Toast.makeText(this, "Function 'Privacy' is not available yet", Toast.LENGTH_SHORT).show();
    }
    public void ClickHelp(View view){
        //goToActivity(this,HelpActivity.class);
        Toast.makeText(this, "Function 'Help' is not available yet", Toast.LENGTH_SHORT).show();
    }
    public void ClickPermissions(View view){
        //goToActivity(this,PermissionsActivity.class);
        Toast.makeText(this, "Function 'Permissions' is not available yet", Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onPause(){
        super.onPause();
        MapsActivity.closeDrawer(drawer);
    }
}