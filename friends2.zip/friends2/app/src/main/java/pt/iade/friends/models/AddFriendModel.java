package pt.iade.friends.models;

public class AddFriendModel {
    private static int imgId;
    //private String friendName;

    public AddFriendModel(int imgId){
        this.imgId = imgId;
        //this.friendName = friendName;
    }
    public static int getImgId(){return imgId;}
    //public String getFriendName(){return friendName;}
    public void setImgId(int imgId) {
        this.imgId = imgId;}
    //public void setFriendName(String friendName) {this.friendName = friendName;}
}
