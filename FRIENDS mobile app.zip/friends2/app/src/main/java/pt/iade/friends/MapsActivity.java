package pt.iade.friends;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.libraries.places.api.Places;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import pt.iade.friends.backgroundtasks.JSONArr;
import pt.iade.friends.backgroundtasks.JSONObj;
import pt.iade.friends.backgroundtasks.JSONObjToArray;
import pt.iade.friends.databinding.ActivityMapsBinding;
import pt.iade.friends.models.SpotIMGModel;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    View view;
    private GoogleMap mMap;
    private ActivityMapsBinding binding;
    DrawerLayout drawer;
    LocationManager locationManager;
    LocationListener locationListener;
    ImageView navProfileBtn;
    EditText searchmap;
    ImageButton searchbt;
    org.json.JSONArray jsonArray = null;
    JSONObject jsonArray3 = null;
    //information on spots


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        drawer = findViewById(R.id.drawer_layout);

        JSONArr task = new JSONArr();

        searchbt = findViewById(R.id.search_map_bt);
        searchmap = findViewById(R.id.search_map_ed);
        searchmap.setVisibility(View.VISIBLE);
        try {
            jsonArray = task.execute("https://friends-mobile-app.herokuapp.com/api/spots/idents/" + "0").get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        navProfileBtn = findViewById(R.id.nav_pro_btn);
        navProfileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClickProfile(v);
            }
        });

        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        locationListener = new LocationListener() {

            @Override
            public void onLocationChanged(@NonNull Location location) {
                //textView.setText(location.toString());
                //Log.i("Location", location.toString());
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
            }

            @Override
            public void onProviderEnabled(String provider) {
            }

            @Override
            public void onProviderDisabled(String provider) {
            }
        };

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    1);
        } else {
            locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    1000,
                    0,
                    locationListener
            );
        }

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }

    public void onClick(View view){

        try {
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonPart = jsonArray.getJSONObject(i);
                if (jsonPart.getString("sptName").equals(searchmap.getText().toString())){
                    goToActivity2(MapsActivity.this,InformationActivity.class, searchmap.getText().toString());

                }else Toast.makeText(this, "Spot not found, try again", Toast.LENGTH_SHORT).show();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        searchmap.setText(null);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER,
                        1000,
                        0,
                        locationListener
                );
            }
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        try {
            Log.i("tamanho", ""+jsonArray.length());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonPart = jsonArray.getJSONObject(i);
                LatLng spots = new LatLng(jsonPart.getDouble("lat"),jsonPart.getDouble("long"));
                mMap.addMarker(new MarkerOptions().position(spots).title(jsonPart.getString("sptName"))
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        LatLng lisboa = new LatLng(38.7166700,-9.1333300);
        mMap.addMarker(new MarkerOptions().position(lisboa).title("Lisboa")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(lisboa, 15));
    }

    //for side menu
    public void ClickMenu(View view) {
        openDrawer(drawer);
    }

    public static void openDrawer(DrawerLayout drawer) {
        drawer.openDrawer(GravityCompat.START);
    }

    public void ClickClose(View view) {
        closeDrawer(drawer);
    }

    public static void closeDrawer(DrawerLayout drawer) {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
    }

    public void ClickMap(View view) {
        closeDrawer(drawer);
    }

    public void ClickProfile(View view) {
        goToActivity(this, ProfileActivity.class);
    }

    public void ClickFriends(View view) {
        goToActivity(this, DisplayFriendsActivity.class);
    }

    public void ClickGroups(View view) {
        goToActivity(this, GroupsActivity.class);
    }

    public void ClickFavouriteSpots(View view) {
        //goToActivity(this,FavouriteSpotsActivity.class);
        Toast.makeText(this, "Function 'Favourite Spots' is not available yet", Toast.LENGTH_SHORT).show();

    }

    public void ClickSettings(View view) {
        //goToActivity(this,SettingsActivity.class);
        Toast.makeText(this, "Function 'Settings' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickAboutUs(View view) {
        //goToActivity(this,AboutUsActivity.class);
        Toast.makeText(this, "Function 'About us' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickDisclaimers(View view) {
        //goToActivity(this,DisclaimersActivity.class);
        Toast.makeText(this, "Function 'Disclaimers' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickNotifications(View view) {
        //goToActivity(this,NotificationsActivity.class);
        Toast.makeText(this, "Function 'Notifications' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickPrivacy(View view) {
        //goToActivity(this,PrivacyActivity.class);
        Toast.makeText(this, "Function 'Privacy' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickHelp(View view) {
        //goToActivity(this,HelpActivity.class);
        Toast.makeText(this, "Function 'Help' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public void ClickPermissions(View view) {
        //goToActivity(this,PermissionsActivity.class);
        Toast.makeText(this, "Function 'Permissions' is not available yet", Toast.LENGTH_SHORT).show();
    }

    public static void goToActivity(Activity activity, Class aClass) {
        Intent intent = new Intent(activity, aClass);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(intent);
    }
    public static void goToActivity2(Activity activity, Class aClass, String sptname) {
        Intent intent = new Intent(activity, aClass);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("SPTNM", sptname);
        activity.startActivity(intent);
    }


    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onPause() {
        super.onPause();
        closeDrawer(drawer);
        stopLocationUpdates();
    }

    private void stopLocationUpdates() {
        locationManager.removeUpdates(locationListener);
    }

}