package pt.iade.friends;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

import pt.iade.friends.backgroundtasks.LoginBackgroundTask;

public class LoginActivity extends AppCompatActivity {
    //button
    Button registerButton;
    Button loginButton;

    //json
    JSONObject loginjson = null;

    //edit text
    private EditText userEditText, passwordEditText;

    //string
    static String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        userEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);

        loginButton = findViewById(R.id.loginbtn);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LoginBackgroundTask task = new LoginBackgroundTask();
                try {
                    loginjson = task.execute("https://friends-mobile-app.herokuapp.com/api/users/" + userEditText.getText().toString() + "/" + passwordEditText.getText().toString()).get();
                    Intent intent = new Intent(getApplicationContext(), ProfileActivity.class);
                    intent.putExtra("key", loginjson.getString("id"));
                    startActivity(intent);
                } catch (ExecutionException e) {
                    e.printStackTrace();
                    loginjson = null;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    loginjson = null;
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

        registerButton = findViewById(R.id.registerButton);
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
                startActivity(intent);
            }
        });
    }
}






