package pt.iade.friends.models;

import java.util.ArrayList;

public class FriendsModel {

    private String nome;
    private ArrayList<UserModel> users;

    public FriendsModel(String nomeFriend)
    {
        this.nome = nomeFriend;
        users = new ArrayList<UserModel>();
    }

    // inserir friend
    public void inserirFriend(UserModel u){users.add(u);}

    // remover friend
    public void removerFriend(UserModel u){users.remove(u);}

    // numero de friend
    //TODO: esta função faz sentido?
    public int numeroFriend(){return  this.users.size();}
}